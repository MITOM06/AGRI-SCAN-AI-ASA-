"use client";

import { useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Suspense } from "react";

function OAuthCallbackHandler() {
  const router = useRouter();
  const searchParams = useSearchParams();

  useEffect(() => {
    const accessToken = searchParams.get("accessToken");
    const refreshToken = searchParams.get("refreshToken");
    const userParam = searchParams.get("user"); // JSON encoded từ backend

    // ── Thiếu token → về login ────────────────────────────────
    if (!accessToken || !refreshToken) {
      router.replace("/login?error=missing_token");
      return;
    }

    // ── Lưu token vào localStorage ────────────────────────────
    localStorage.setItem("accessToken", accessToken);
    localStorage.setItem("refreshToken", refreshToken);

    // ── Parse user object nếu backend gửi về ─────────────────
    let isPasswordSet = true; // mặc định true để không bị redirect nhầm
    if (userParam) {
      try {
        const userData = JSON.parse(decodeURIComponent(userParam));
        localStorage.setItem("user", JSON.stringify(userData));
        isPasswordSet = userData.isPasswordSet !== false;
      } catch {
        // Parse lỗi → không sao, AuthProvider sẽ tự fetch profile
      }
    }

    if (!isPasswordSet) {
      window.location.href = "/set-password";
    } else {
      window.location.href = "/";
    }
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50">
      <div className="text-center">
        <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <p className="text-gray-600 font-medium">Đang xử lý đăng nhập...</p>
        <p className="text-gray-400 text-sm mt-2">Vui lòng chờ trong giây lát</p>
      </div>
    </div>
  );
}

export default function OAuthCallbackPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex items-center justify-center bg-gray-50">
          <div className="w-12 h-12 border-4 border-emerald-500 border-t-transparent rounded-full animate-spin" />
        </div>
      }
    >
      <OAuthCallbackHandler />
    </Suspense>
  );
}